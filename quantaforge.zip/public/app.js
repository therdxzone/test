'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
let csrf = '', role = '', timer = null;
async function api(p, o = {}) {
  const r = await fetch('/api' + p, { method: o.method || 'GET', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: o.body ? JSON.stringify(o.body) : undefined });
  let d = {}; try { d = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(d.error || 'Request failed'); e.status = r.status; e.data = d; throw e; }
  return d;
}
function toast(m, bad) { const t = $('#toast'); t.textContent = m; t.className = 'toast show' + (bad ? ' bad' : ''); setTimeout(() => t.className = 'toast', 3500); }
const GB = b => b == null ? 'N/A' : (b / 2 ** 30).toFixed(1) + ' GB';
const pct = (a, b) => a == null || !b ? null : 100 * a / b;
const P = v => v == null ? 'N/A' : v.toFixed(1) + '%';
const upt = s => `${Math.floor(s / 86400)}d ${Math.floor(s % 86400 / 3600)}h ${Math.floor(s % 3600 / 60)}m`;
function applyBrand(b) {
  const st = document.documentElement.style; st.setProperty('--p', b.primary_color); st.setProperty('--s', b.secondary_color);
  document.title = b.panel_name; $$('.pname').forEach(e => e.textContent = b.panel_name); $$('.logo').forEach(i => i.src = b.logo_url); $('#pol').href = b.policy_url;
}
$('#acc').onchange = () => $('#loginBtn').disabled = !$('#acc').checked;
$('#loginForm').onsubmit = async e => {
  e.preventDefault(); $('#loginErr').textContent = '';
  try { const d = await api('/login', { method: 'POST', body: { password: $('#pw').value, accepted: $('#acc').checked } }); $('#pw').value = ''; csrf = d.csrf; enter(d.role, d.mustChange); }
  catch (err) { $('#loginErr').textContent = err.message; }
};
$('#logout').onclick = async () => { try { await api('/logout', { method: 'POST' }); } catch {} location.reload(); };
function enter(r, mustChange) {
  role = r; $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
  $('#roleTag').textContent = r === 'admin' ? 'ADMIN' : 'USER';
  $$('.adminonly').forEach(e => e.classList.toggle('hidden', r !== 'admin'));
  $('#pwSec').classList.toggle('hidden', r !== 'admin');
  $('#dash').classList.toggle('hidden', mustChange);
  if (mustChange) { $('#pwNote').textContent = 'You must change the initial admin password before continuing.'; $('#pwTarget').value = 'admin'; $('#pwTarget').classList.add('hidden'); return; }
  if (r === 'admin') loadSettings();
  tick(); clearInterval(timer); timer = setInterval(tick, 5000);
}
async function tick() {
  try {
    if (role === 'admin') { const d = await api('/admin/overview'); render(d.vps, d.os); chart(d.history); logs(d.logs); } else render(await api('/vps'));
  } catch (e) { if (e.status === 401) location.reload(); }
}
function stat(label, val, p) { const d = document.createElement('div'); d.className = 'stat'; const s = document.createElement('span'); s.textContent = label; const b = document.createElement('b'); b.textContent = val; d.append(s, b);
  if (p != null) { const bar = document.createElement('div'); bar.className = 'bar'; const i = document.createElement('i'); i.style.width = Math.min(100, p) + '%'; bar.append(i); d.append(bar); } return d; }
function render(v, osn) {
  $('#host').textContent = v.hostname; $('#sub').textContent = `Plan: ${v.plan}` + (osn ? ` · ${osn}` : '');
  const s = $('#status'); s.textContent = v.status; s.className = 'badge ' + v.status;
  const susp = v.status === 'Suspended';
  $('#susp').classList.toggle('hidden', !(susp && role === 'user'));
  $('#sshx').disabled = susp && role === 'user';
  $('#stats').replaceChildren(
    stat('CPU allocation', `${v.cpuCores} vCPU`), stat('RAM allocation', GB(v.ramTotal)), stat('Storage allocation', GB(v.diskTotal)),
    stat('CPU usage', P(v.cpuPct), v.cpuPct), stat('RAM usage', `${GB(v.ramUsed)} (${P(pct(v.ramUsed, v.ramTotal))})`, pct(v.ramUsed, v.ramTotal)),
    stat('Disk usage', `${GB(v.diskUsed)} (${P(pct(v.diskUsed, v.diskTotal))})`, pct(v.diskUsed, v.diskTotal)), stat('Uptime', upt(v.uptime)));
  $('#upd').textContent = 'Last updated: ' + (v.updated ? new Date(v.updated).toLocaleTimeString() : 'N/A');
  $('#bSusp').disabled = susp; $('#bUnsusp').disabled = !susp;
  $('#modeNote').textContent = v.suspensionMode === 'host' ? 'Host-side controller configured: suspension is enforced by the hypervisor.' : 'Application-level suspension: blocks user access and SSHX only. The VM itself is NOT stopped.';
}
function chart(h) {
  const c = $('#chart'), x = c.getContext('2d'), W = c.width, H = c.height; x.clearRect(0, 0, W, H); x.strokeStyle = '#202938';
  for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(0, i * H / 4); x.lineTo(W, i * H / 4); x.stroke(); }
  const css = getComputedStyle(document.documentElement);
  [['cpu', css.getPropertyValue('--p')], ['ram', css.getPropertyValue('--s')]].forEach(([k, col]) => {
    x.strokeStyle = col.trim(); x.lineWidth = 2; x.beginPath(); let st = false;
    h.forEach((p, i) => { if (p[k] == null) return; const px = i * W / Math.max(1, h.length - 1), py = H - p[k] / 100 * H; st ? x.lineTo(px, py) : x.moveTo(px, py); st = true; }); x.stroke();
  });
}
function logs(rows) { $('#logs').replaceChildren(...rows.map(r => { const d = document.createElement('div'); const k = document.createElement('span'); k.className = 'k'; k.textContent = `[${r.kind}] `; d.append(new Date(r.ts).toLocaleString() + ' ', k, r.msg); return d; })); }
$('#logKind').onchange = async () => logs(await api('/admin/logs?kind=' + $('#logKind').value));
$('#sshx').onclick = async () => {
  $('#sshxMsg').textContent = 'Starting session…';
  try { const d = await api('/sshx', { method: 'POST' }); $('#sshxMsg').textContent = ''; window.open(d.url, '_blank', 'noopener,noreferrer'); }
  catch (e) { $('#sshxMsg').textContent = ''; toast(e.message, true); }
};
async function act(path, confirmMsg) {
  if (confirmMsg && !confirm(confirmMsg)) return;
  try { await api(path, { method: 'POST' }); toast('Done'); tick(); } catch (e) { toast(e.message, true); }
}
$('#bSusp').onclick = () => act('/admin/suspend', 'Suspend the VPS? Users will be blocked immediately.');
$('#bUnsusp').onclick = () => act('/admin/unsuspend', 'Unsuspend the VPS?');
$('#bRefresh').onclick = () => act('/admin/refresh');
$('#pwBtn').onclick = async () => {
  try { await api('/admin/password', { method: 'POST', body: { current: $('#pwCur').value, target: $('#pwTarget').value, newPassword: $('#pwNew').value } }); toast('Password updated. Please log in again.'); setTimeout(() => location.reload(), 1200); }
  catch (e) { toast(e.message, true); }
};
const FIELDS = [['panel_name', 'Panel name', 'text'], ['logo_url', 'Logo URL (https)', 'text'], ['policy_url', 'Policy website (https)', 'text'], ['primary_color', 'Primary color', 'color'], ['secondary_color', 'Secondary color', 'color'], ['plan_name', 'VPS plan name', 'text'],
  ['cpu_threshold', 'CPU threshold %', 'number'], ['ram_threshold', 'RAM threshold %', 'number'], ['duration_min', 'Consecutive minutes above threshold', 'number'], ['interval_s', 'Monitoring interval (seconds)', 'number'], ['auto_enabled', 'Automatic suspension enabled', 'checkbox']];
async function loadSettings() {
  const s = await api('/admin/settings'); const box = $('#setFields'); box.replaceChildren();
  for (const [k, l, t] of FIELDS) {
    const w = document.createElement('div'), lab = document.createElement('label'), i = document.createElement('input');
    lab.className = 'f'; lab.textContent = l; i.type = t; i.name = k; if (t === 'checkbox') { i.checked = s[k]; i.style.width = 'auto'; } else i.value = s[k]; w.append(lab, i); box.append(w);
  }
}
$('#setForm').onsubmit = async e => {
  e.preventDefault(); const body = {};
  for (const [k, , t] of FIELDS) { const i = $(`[name=${k}]`); body[k] = t === 'checkbox' ? i.checked : t === 'number' ? Number(i.value) : i.value; }
  try { await api('/admin/settings', { method: 'PUT', body }); toast('Settings saved'); applyBrand(await api('/branding')); } catch (er) { toast(er.message, true); }
};
(async () => {
  applyBrand(await fetch('/api/branding').then(r => r.json()));
  try { const d = await api('/me'); csrf = d.csrf; enter(d.role, d.mustChange); } catch {}
})();
